# EngineNext Complete

Projects:
- EngineNext.Core
- EngineNext.Platform
- EngineNext.Platform.Windows
- EngineNext.Demo

Target frameworks:
- net10.0
- net10.0-windows

This drop includes:
- code-first scenes, actors, prefabs
- default transform on every actor
- axis-separated 2D collision against solid actors
- native Win32 window host
- software 2D renderer
- attribute-driven UI windows
- action-based input bindings
- demo scene with a welcome screen and Play button
